package com.example.mob_comp_hw.ui.notification

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun Notification(
    onBackPress: () -> Unit
) {
    Surface {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopAppBar {
                IconButton(
                    onClick = onBackPress
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null
                    )
                }
                Text(text = "Notification")
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.padding(28.dp)
            ) {
                OutlinedTextField(
                    value = "",
                    onValueChange ={ },
                    label = { Text(text = "What do you need to remember?") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = "",
                    onValueChange ={ },
                    label = { Text(text = "Date") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = { /*TODO*/ },
                    modifier =  Modifier.fillMaxWidth().size(60.dp),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Save reminder")
                }
            }
        }
    }
}