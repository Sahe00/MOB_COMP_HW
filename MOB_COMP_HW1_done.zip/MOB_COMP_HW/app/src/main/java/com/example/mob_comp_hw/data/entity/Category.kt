package com.example.mob_comp_hw.data.entity

data class Category(
    val id: Long,
    val name: String
)
