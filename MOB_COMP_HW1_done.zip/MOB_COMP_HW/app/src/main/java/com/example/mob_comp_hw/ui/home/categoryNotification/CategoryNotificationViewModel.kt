package com.example.mob_comp_hw.ui.home.categoryNotification


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mob_comp_hw.data.entity.Notification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.*

class CategoryNotificationViewModel : ViewModel() {
    private val _state = MutableStateFlow(CategoryNotificationViewState())

    val state: StateFlow<CategoryNotificationViewState>
        get() = _state

    init {
        val list = mutableListOf<Notification>()
        for (x in 1..10) {
            list.add(
                Notification(
                    notificationId = x.toLong(),
                    notificationTitle = "$x reminder",
                    notificationCategory = "Education",
                    notificationDate = Date()
                )
            )
        }

        viewModelScope.launch {
            _state.value = CategoryNotificationViewState(
                notifications = list
            )
        }
    }
}

data class CategoryNotificationViewState(
    val notifications: List<Notification> = emptyList()
)

