package com.example.mob_comp_hw.data.entity

import java.util.*

data class Notification(
    val notificationId: Long,
    val notificationTitle: String,
    val notificationDate: Date?,
    val notificationCategory: String
)
