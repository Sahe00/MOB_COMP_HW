package com.example.mob_comp_hw

import android.app.Application

class NotificationApplicationRE : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.provide(this)
    }
}