package com.example.mob_comp_hw

import android.content.Context
import androidx.room.Room
import com.example.mob_comp_hw.data.room.repository.CategoryRepository
import com.example.mob_comp_hw.data.room.MobileComputingDatabase
import com.example.mob_comp_hw.data.room.repository.NotificationRepository

/**
 * Normally you'd want to use Koin/Dagger/Hilt instead
 */

object Graph {
    lateinit var database: MobileComputingDatabase
        private set

    lateinit var appContext: Context

    val categoryRepository by lazy {
        CategoryRepository(
            categoryDao = database.categoryDao()
        )
    }

    val notificationRepository by lazy {
        NotificationRepository(
            notificationDao = database.notificationDao()
        )
    }


    fun provide(context: Context) {
        appContext = context
        database = Room.databaseBuilder(context, MobileComputingDatabase::class.java, "data.db")
            .fallbackToDestructiveMigration()
            .allowMainThreadQueries()
            .build()
    }
}