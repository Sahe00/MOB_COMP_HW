package com.example.mob_comp_hw.ui.notification

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.mob_comp_hw.util.viewModelProviderFactoryOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import kotlinx.coroutines.launch
import java.util.*

//private fun getCategoryId(categories: List<Category>, categoryName: String): Long {
//    return categories.first { category -> category.name == categoryName }.id
//} // TESTI SAADAANKO KATEGORIAT TOIMIMAAN EDIT -IKKUNASSA

@Composable
fun EditNotification(
    onBackPress: () -> Unit,
    notificationId: Long,
    navController: NavController,
    viewModel2: NotificationViewModel = viewModel()
) {
    val viewModel: EditNotificationViewModel = viewModel(
        key = "notification_id_$notificationId",
        factory = viewModelProviderFactoryOf {
            EditNotificationViewModel(notificationId)
        }
    )
    val viewState by viewModel.state.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var notification: Notification = viewModel2.getNotificationWithId(notificationId)

    //Main message
    val appTitle = viewState.notification?.notificationTitle ?: ""
    val title = rememberSaveable { mutableStateOf("") }
    title.value = appTitle

    //Time
    val appNotificationTime = viewState.notification?.notificationTime ?: ""
    val notificationTime = rememberSaveable { mutableStateOf("") }
    notificationTime.value = appNotificationTime

    //Hour
    val appNotificationHour = viewState.notification?.notificationHour ?: ""
    val notificationHour = rememberSaveable { mutableStateOf("") }
    notificationHour.value = appNotificationHour

    //Notification seen or not
    val appNotificationSeen = viewState.notification?.notificationReminderSeen ?: ""
    val notificationSeen = rememberSaveable { mutableStateOf("") }
    notificationSeen.value = appNotificationSeen.toString()

    //Vibration
    val appNotificationVibration = viewState.notification?.notificationVibration ?: ""
    val notificationVibration = rememberSaveable { mutableStateOf("") }
    notificationVibration.value = appNotificationVibration.toString()

    //Sec, min, hour
    val seconds = rememberSaveable{ mutableStateOf("") }
    val minutes = rememberSaveable{ mutableStateOf("") }
    val hours = rememberSaveable { mutableStateOf("") }

    //Longitude & Latitude and all that
//    val latlng = navController
//        .currentBackStackEntry
//        ?.savedStateHandle
//        ?.getLiveData<LatLng>("location_data")
//        ?.value

    val appNotificationLocationX = viewState.notification?.notificationLocation_x ?: 0.0
    val appNotificationLocationY = viewState.notification?.notificationLocation_y ?: 0.0
    val notificationLocationX = rememberSaveable { mutableStateOf(0.0) }
    val notificationLocationY = rememberSaveable { mutableStateOf(0.0) }
    notificationLocationX.value = appNotificationLocationX
    notificationLocationY.value = appNotificationLocationY

    // Location
    val appNotificationLocation = viewState.notification?.notificationLocation ?: ""
    val notificationLocation = rememberSaveable { mutableStateOf("") }
    notificationLocation.value = appNotificationLocation.toString()

//    if(latlng != null){
//        notificationLocationX.value = latlng.latitude
//        notificationLocationY.value = latlng.longitude

    Surface(

    ){
        val context = LocalContext.current

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopAppBar {
                IconButton(
                    onClick = onBackPress
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Return"
                    )
                }
                Text(
                    text = "Edit reminder",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            Spacer(modifier = Modifier.height(50.dp))
            OutlinedTextField(
                value = title.value,
                onValueChange = { title.value = it },
                label = { Text(text = "Message")},
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(50)
            )
            Spacer(modifier = Modifier.height(30.dp))
//            Row(verticalAlignment = Alignment.CenterVertically) {
//                Text(
//                    text = "The timer : " + notificationHour.value,
//                    fontSize = 20.sp
//                )
//            }
//            Row(
//                modifier = Modifier.fillMaxWidth()
//            ){
//                Column(
//                    modifier = Modifier.fillMaxWidth()
//                ) {
//                    OutlinedTextField(
//                        value = hours.value,
//                        onValueChange = { hours.value = it },
//                        label = { Text(text = "Hours") },
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number
//                        ),
//                    )
//                }
//                Spacer(modifier = Modifier.width(16.dp))
//                Column(
//                    modifier = Modifier.width(110.dp)
//                ) {
//                    OutlinedTextField(
//                        value = minutes.value,
//                        onValueChange = { minutes.value = it },
//                        label = { Text(text = "Minutes") },
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number
//                        ),
//
//                    )
//                }
//                Spacer(modifier = Modifier.width(16.dp))
//                Column(
//                    modifier = Modifier.width((110.dp))
//                ) {
//                    OutlinedTextField(
//                        value = seconds.value,
//                        onValueChange = { seconds.value = it },
//                        label = { Text(text = "Seconds") },
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number
//                        )
//                    )
//                }
//            } //TAMA KANS TAKAISIN ENS KERRALLA
            Spacer(modifier = Modifier.height(30.dp))
//            if (notificationLocationX.value == 0.0 && notificationLocationY.value == 0.0) {
//                Button(
//                    onClick = { navController.navigate("map") },
//                ) {
//                    Text(text = "Edit location",
//                        color = Color.LightGray,
//                        fontSize = 20.sp
//                    )
//                }
//            }
//            else {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Button(
//                        onClick = { navController.navigate("map") },
//                    ){
//                        Text(text = "Change location",
//                            color = Color.LightGray,
//                            fontSize = 20.sp
//                        )
//                    }
//                }
//            }  TAMAN VOI TARVITTAESSA LISATA TAKAISIN
            Spacer(modifier = Modifier.height(30.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
//                Checkbox(checked = notificationVibration.value.toBoolean(),
//                    onCheckedChange = { notificationVibration.value = it.toString() },
//                )
//                Text(
//                    text = "Vibration"
//                )  // TAMAN VOI TARVITTAESSA LISATA TAKAISIN
            }
            Spacer(modifier = Modifier.height(80.dp))
            Button(
                onClick = {
                    coroutineScope.launch {
                        if(hours.value == ""){hours.value="0"}
                        if(minutes.value == ""){minutes.value="0"}
                        if(seconds.value == ""){seconds.value="0"}
//                        var locx = (latlng?.latitude ?: 0.0)  // LATLNG KUN TARVITAAN LOKAATIO
//                        var locy = (latlng?.longitude ?: 0.0)
//                        if(reminderLocation.value.toBoolean()){
//                            locx = 0.0
//                            locy = 0.0
//                        }
                        viewModel.saveNotification(
                            Notification(
                                notificationId = notificationId,
                                notificationTitle = title.value,
                                notificationTime = (((hours.value.toLong()*60*60)+minutes.value.toLong())*60+seconds.value.toLong()).toString(),
                                notificationCreationTime = Date().time,
                                notificationCategoryId = notification.notificationCategoryId,
                                notificationLocation_x = null, // TOISTAISEKSI NULL, KUNNES TARVITAAN LOKAATIO
                                notificationLocation_y = null, // TOISTAISEKSI NULL, KUNNES TARVITAAN LOKAATIO
                                notificationCreatorId = 0,
                                notificationReminderSeen = if(notificationSeen.value.toInt() == 1 || (((hours.value.toLong()*60*60)+minutes.value.toLong())*60+seconds.value.toLong()).toString() != "0"){
                                    0
                                }else{
                                    1
                                },
                                notificationHour = hours.value + "h" + minutes.value + "m" + seconds.value + "s",
                                notificationVibration = notificationVibration.value.toBoolean(),
                                notificationLocation = notificationLocation.value.toBoolean()
                            )
                        )
                            Toast.makeText(context, "Notification has been modified!", Toast.LENGTH_SHORT).show()
                        }
                        onBackPress()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .size(52.dp)
                    ) {
                        Text(text = "Save changes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color.LightGray,
                        )
            }
        }

    }


}

