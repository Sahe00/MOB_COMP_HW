package com.example.mob_comp_hw.data.room.repository

import com.example.mob_comp_hw.data.entity.Notification
import com.example.mob_comp_hw.data.room.NotificationDao
import com.example.mob_comp_hw.data.room.NotificationToCategory
import kotlinx.coroutines.flow.Flow

/**
 * A data repository for [Notification] instances
 */
class NotificationRepository(
    private val notificationDao: NotificationDao
) {
    /**
     * Returns a flow containing the list of notifications associated with [categoryId]
     */
    fun notificationsInCategory(categoryId: Long) : Flow<List<NotificationToCategory>> {
        return notificationDao.notificationsFromCategory(categoryId)
    }

    fun getNotificationWithId(id: Long): Notification = notificationDao.notification(id)
    /**
     *  Add a new [Notification]
     */
    //MIGHT CAUSE AN ERROR
    suspend fun addNotification(notification: Notification) = notificationDao.insert(notification)
    suspend fun removeReminderById(id: Long) = notificationDao.deleteById(id)
    suspend fun updateNotification(notification: Notification) = notificationDao.update(notification)
    suspend fun getNotification(id: Long) = notificationDao.notification(id)
    suspend fun updateSeen(id: Long) = notificationDao.updateSeen(id)
    suspend fun updateSeenBack(id: Long) = notificationDao.updateSeenBack(id)
}