package com.example.mob_comp_hw.data.room

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification

/**
 * The [RoomDatabase] for the app
 */
@Database(
    entities = [Category::class, Notification::class],
    version = 6,
    exportSchema = false
)
abstract class MobileComputingDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun notificationDao(): NotificationDao
}