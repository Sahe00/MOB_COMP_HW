package com.example.mob_comp_hw.ui.notification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mob_comp_hw.Graph
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import com.example.mob_comp_hw.data.room.repository.CategoryRepository
import com.example.mob_comp_hw.data.room.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class NotificationViewModel(
    private val notificationRepository: NotificationRepository = Graph.notificationRepository,
    private val categoryRepository: CategoryRepository = Graph.categoryRepository
): ViewModel() {
    private val _state = MutableStateFlow(NotificationViewState())

    val state: StateFlow<NotificationViewState>
        get() = _state

    suspend fun saveNotification(notification: Notification): Long {
        return notificationRepository.addNotification(notification)
    }

    fun getNotificationWithId(id: Long): Notification {
        return notificationRepository.getNotificationWithId(id)
    }

    init {
        viewModelScope.launch {
            categoryRepository.categories().collect { categories ->
                _state.value = NotificationViewState(categories)
            }
        }
    }
}

data class NotificationViewState(
    val categories: List<Category> = emptyList()
)