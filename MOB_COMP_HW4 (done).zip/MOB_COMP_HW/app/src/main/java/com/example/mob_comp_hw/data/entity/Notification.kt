package com.example.mob_comp_hw.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDateTime

@Entity(
    tableName = "notifications",
    indices = [
        Index("id", unique = true),
        Index("category_id")
    ],
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["id"],
            childColumns = ["category_id"],
            onUpdate = ForeignKey.CASCADE,
            onDelete = ForeignKey.CASCADE
        )
    ]
)

data class Notification(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "id") val notificationId: Long = 0,

    @ColumnInfo(name = "message") val notificationTitle: String,
    @ColumnInfo(name = "location_x") val notificationLocation_x: Double,
    @ColumnInfo(name = "location_y") val notificationLocation_y: Double,
    @ColumnInfo(name = "notification_time") val notificationTime: String, // Might need to be "String"
    @ColumnInfo(name = "creation_time") val notificationCreationTime: Long,
    @ColumnInfo(name = "creator_id") val notificationCreatorId: Long,
    @ColumnInfo(name = "category_id") val notificationCategoryId: Long, // Might be unnecessary
    @ColumnInfo(name = "notification_seen") val notificationReminderSeen: Long,
    @ColumnInfo(name = "notification_hour") val notificationHour: String,
    @ColumnInfo(name = "notification_vibration") val notificationVibration: Boolean,
    @ColumnInfo(name = "notification_location") val notificationLocation: Boolean
)
