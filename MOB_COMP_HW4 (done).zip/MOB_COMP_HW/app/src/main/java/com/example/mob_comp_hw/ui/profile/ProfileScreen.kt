package com.example.mob_comp_hw.ui.profile

import android.content.Context
import android.net.Uri
import android.preference.PreferenceManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.mob_comp_hw.R
import com.example.mob_comp_hw.ui.SharedPreferences
import coil.compose.rememberAsyncImagePainter
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext

@Composable
fun ProfModify(context: Context, modifier: Modifier = Modifier) {
    val imageUri = rememberSaveable {
        mutableStateOf("")
    }
    val prefs = PreferenceManager.getDefaultSharedPreferences(context)

    // Load the saved image URI from the preferences
    LaunchedEffect(Unit) {
        val savedUri = prefs.getString("profile_image_uri", "")
        if (!savedUri.isNullOrEmpty()) {
            imageUri.value = savedUri
        }
    }

    val painter = rememberAsyncImagePainter(
        if (imageUri.value.isEmpty()) {
            R.mipmap.ic_person
        } else {
            imageUri.value
        }
    )

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            // Save the URI in the preferences
            prefs.edit().putString("profile_image_uri", it.toString()).apply()
            imageUri.value = it.toString()
            Toast.makeText(context, "Profile icon changed successfully", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            shape = CircleShape,
            modifier = Modifier
                .size(190.dp) // Had to be doubled in size to fit properly
        ) {
            Image(
                painter = painter,
                contentDescription = "The image for your profile picture.",
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { launcher.launch("image/*") },
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
fun Profile(
    navController: NavController, context: Context
) {
    val localFocus = LocalFocusManager.current
    val imageStatus = rememberSaveable { mutableStateOf("") }

    if (imageStatus.value.isNotEmpty()) {
        Toast.makeText(LocalContext.current, imageStatus.value, Toast.LENGTH_SHORT).show()
        imageStatus.value = ""
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        val username = remember { mutableStateOf("") }
        val password = remember { mutableStateOf("") }
        val userPreferences = SharedPreferences(context)
        val usernameShow = userPreferences.username

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopAppBar {
                IconButton(
                    onClick = { navController.popBackStack() }
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack,
                        contentDescription = null)
                }
                Text(
                    text = "My profile",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            ProfModify(context)

                Text(text = "Username: $usernameShow",
                    style = MaterialTheme.typography.h6)

            Spacer(modifier = Modifier.height(30.dp))

            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = username.value,
                onValueChange ={ text -> username.value = text },
                label = { Text(text = "Username") },
                shape = RoundedCornerShape(50),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = password.value,
                onValueChange = { passwordString -> password.value = passwordString},
                label = { Text(text = "Password") },
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(50),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password
                )

            )

            Spacer(modifier = Modifier.height(30.dp))

        }
    }
}

