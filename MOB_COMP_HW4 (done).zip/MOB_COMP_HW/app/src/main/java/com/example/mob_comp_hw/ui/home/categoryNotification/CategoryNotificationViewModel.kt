package com.example.mob_comp_hw.ui.home.categoryNotification


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mob_comp_hw.Graph
import com.example.mob_comp_hw.data.room.NotificationToCategory
import com.example.mob_comp_hw.data.room.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch


class CategoryNotificationViewModel(
    private val categoryId: Long,
    private val notificationRepository: NotificationRepository = Graph.notificationRepository
) : ViewModel() {
    private val _state = MutableStateFlow(CategoryNotificationViewState())

    val state: StateFlow<CategoryNotificationViewState>
        get() = _state

    init {
        viewModelScope.launch {
            notificationRepository.notificationsInCategory(categoryId).collect { list ->
                _state.value = CategoryNotificationViewState(
                    notifications = list
                )
            }
        }
    }
    suspend fun deleteNotification(id :Long){     //MAY NEED TO BE DEFINED ABOVE
        Graph.notificationRepository.removeReminderById(id)
    }
}

data class CategoryNotificationViewState(
    val notifications: List<NotificationToCategory> = emptyList()
)

