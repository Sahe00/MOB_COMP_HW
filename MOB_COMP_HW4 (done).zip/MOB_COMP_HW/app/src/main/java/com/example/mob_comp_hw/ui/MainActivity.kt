package com.example.mob_comp_hw.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.mob_comp_hw.ui.login.LoginScreen
import com.example.mob_comp_hw.ui.theme.MOB_COMP_HWTheme
import android.content.Context


class MainActivity : ComponentActivity() {
    lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val credentials = SharedPreferences(this)
        credentials.username = "Test"
        credentials.password = "1234"

        setContent {
            MOB_COMP_HWTheme(darkTheme = false) {
                // A surface container using the 'background' color from the theme
                Surface(
                    color = MaterialTheme.colors.background) {
                        NotificationApp(context = applicationContext)
                }

            }
        }
    }
}

