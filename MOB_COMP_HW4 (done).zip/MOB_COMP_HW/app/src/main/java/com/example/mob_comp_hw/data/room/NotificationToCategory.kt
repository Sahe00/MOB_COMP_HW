package com.example.mob_comp_hw.data.room

import androidx.room.Embedded
import androidx.room.Ignore
import androidx.room.Relation
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import java.util.Objects

class NotificationToCategory {
    @Embedded
    lateinit var notification: Notification

    @Relation(parentColumn = "category_id", entityColumn = "id")
    lateinit var _categories: List<Category>

    @get:Ignore
    val category: Category
        get() = _categories[0]

    /**
     * Allow this class to be destructed by consumers
     */
    operator fun component1() = notification
    operator fun component2() = category

    override fun equals(other: Any?): Boolean = when {
        other === this -> true
        other is NotificationToCategory -> notification == other.notification && _categories == other._categories
        else -> false
    }

    override fun hashCode(): Int = Objects.hash(notification, _categories)
}
