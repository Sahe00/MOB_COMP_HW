package com.example.mob_comp_hw.ui

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.mob_comp_hw.NotificationAppState
import com.example.mob_comp_hw.rememberNotificationAppState
import com.example.mob_comp_hw.ui.home.Home
import com.example.mob_comp_hw.ui.home.categoryNotification.NotificationList2
import com.example.mob_comp_hw.ui.login.LoginScreen
import com.example.mob_comp_hw.ui.map.NotificationLocationMap
import com.example.mob_comp_hw.ui.notification.EditNotification
import com.example.mob_comp_hw.ui.notification.Notification
import com.example.mob_comp_hw.ui.profile.Profile

@Composable
fun NotificationApp(context: Context,
    appState: NotificationAppState = rememberNotificationAppState()
) {
    NavHost(
        navController = appState.navController,
        startDestination = "login"
    ) {
        composable(route = "login") {
            LoginScreen(navController = appState.navController, context)
        }
        composable(route = "home") {
            Home(navController = appState.navController)
        }
        composable(route = "notification") {
            Notification(onBackPress = appState::navigateBack,
                navController = appState.navController)
        }
        composable(route = "profile") {
            Profile(navController = appState.navController, context)
        }
        composable(route = "notificationList") {
            NotificationList2(navController = appState.navController, context)
        }
        composable(route = "editNotification/{id}",
            arguments = listOf(
                navArgument("id") {
                    type = NavType.LongType
                }
            )
        ) {
                backStackEntry ->
            val id = backStackEntry.arguments?.getLong("id")
            EditNotification(
                navController = appState.navController,
                onBackPress = appState::navigateBack,
                notificationId = id ?: 0
            )
        }
        composable(route = "map") {
            NotificationLocationMap(
                navController = appState.navController)
        }
    }
}