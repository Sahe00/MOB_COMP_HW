package com.example.mob_comp_hw.ui.home.categoryNotification

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.constraintlayout.compose.Dimension
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.mob_comp_hw.Graph.notificationRepository
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import com.example.mob_comp_hw.data.room.NotificationToCategory
import com.example.mob_comp_hw.ui.home.HomeViewModel
import com.example.mob_comp_hw.util.viewModelProviderFactoryOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CategoryNotification(
    categoryId: Long,
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier,
    navController: NavController
) {
    val viewModel: CategoryNotificationViewModel = viewModel(
        key = "category_list_$categoryId",
        factory = viewModelProviderFactoryOf { CategoryNotificationViewModel(categoryId) }
    )
    val viewState by viewModel.state.collectAsState()

    Column(Modifier.fillMaxWidth()) {
        NotificationList(
            list = viewState.notifications,
            navController = navController,
            viewModel = viewModel,
        )
    }
}

@Composable
private fun NotificationList(
    list: List<NotificationToCategory>,
    navController: NavController,
    viewModel: CategoryNotificationViewModel,
) {
    LazyColumn(
        contentPadding = PaddingValues(0.dp),
        verticalArrangement = Arrangement.Center
    ) {
        items(list) { item ->    //HERE THE CHANGES FOR NOTIFICATION SEEN
            NotificationListItem(
                notification = item.notification,
                viewModel = viewModel,
                category = item.category,
                onClick = { },
                modifier = Modifier.fillParentMaxWidth(),
                navController = navController
            )
        }
    }
}

@Composable
private fun NotificationListItem(
    notification: Notification,
    viewModel: CategoryNotificationViewModel,
    category: Category,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    navController: NavController
) {
    ConstraintLayout(modifier = modifier.clickable { onClick() }) {
        val (divider, notificationTitle, notificationCategory, iconEdit, iconDelete, date) = createRefs()
        Divider(
            Modifier.constrainAs(divider) {
                top.linkTo(parent.top)
                centerHorizontallyTo(parent)
                width = Dimension.fillToConstraints
            }
        )

        val coroutineScope = rememberCoroutineScope()

        // This is title
        Text(
            text = notification.notificationTitle,
            maxLines = 1,
            style = MaterialTheme.typography.subtitle1,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.constrainAs(notificationTitle) {
                linkTo(
                    start = parent.start,
                    end = iconDelete.start,
                    startMargin = 24.dp,
                    endMargin = 16.dp,
                    bias = 0f // Float this towards the start. This was apparently a fix
                )
                top.linkTo(parent.top, margin = 10.dp)
                width = Dimension.preferredWrapContent
            }
        )

        // This is category
        Text(
            text = category.name,
            maxLines = 1,
            style = MaterialTheme.typography.subtitle2,
            modifier = Modifier.constrainAs(notificationCategory) {
                linkTo(
                    start = parent.start,
                    end = iconEdit.start,
                    startMargin = 24.dp,
                    endMargin = 8.dp,
                    bias = 0f // float this towards the start. this was is the fix we needed
                )
                top.linkTo(notificationTitle.bottom, margin = 6.dp)
                bottom.linkTo(parent.bottom, 10.dp)
                width = Dimension.preferredWrapContent
            }
        )

        // This is date
        Text(
            text = notification.notificationCreationTime.toDateString(),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.caption,
            modifier = Modifier.constrainAs(date) {
                linkTo(
                    start = notificationCategory.end,
                    end = iconEdit.start,
                    startMargin = 8.dp,
                    endMargin = 16.dp,
                    bias = 0f // float this towards the start. this was is the fix we needed
                )
                centerVerticallyTo(notificationCategory)
                top.linkTo(notificationTitle.bottom, 6.dp)
                bottom.linkTo(parent.bottom, 10.dp)
            }
        )

        //val editIcon = Icons.Filled.Edit
        //val deleteIcon = Icons.Filled.Delete

        IconButton(
            onClick = {
                navController.navigate(route = "editnotification/${notification.notificationId}")
        },
        modifier = Modifier
            .size(25.dp)
            .padding(1.dp)
            .constrainAs(iconEdit) {
                top.linkTo(parent.top, 10.dp)
                bottom.linkTo(parent.bottom, 10.dp)
                end.linkTo(parent.end, 50.dp)
            }
        ) {
            Icon(
                imageVector = Icons.Filled.Edit,
                contentDescription = "Edit"
            )
        }


        // This is for the checkmark icon
        IconButton(
            onClick = {
                coroutineScope.launch {
                    viewModel.deleteNotification(notification.notificationId)
                }
            },
            modifier = Modifier
                .size(50.dp)
                .padding(6.dp)
                .constrainAs(iconDelete) {
                    top.linkTo(parent.top, 10.dp)
                    bottom.linkTo(parent.bottom, 10.dp)
                    end.linkTo(parent.end, 5.dp)
                }
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Delete"
            )
        }
    }
}

fun updateSeen(notification: Notification) {
    if(notification.notificationLocation_x == 0.0 && notification.notificationLocation_y == 0.0){
        val scope = CoroutineScope(Dispatchers.Default)
        scope.launch {
            notificationRepository.updateSeenBack(notification.notificationId)
        }
    } else{}
}

private fun Date.formatToString(): String {
    return SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(this)
}

fun Long.toDateString(): String {
    return SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date(this))
}

//LOCATION BS HERE