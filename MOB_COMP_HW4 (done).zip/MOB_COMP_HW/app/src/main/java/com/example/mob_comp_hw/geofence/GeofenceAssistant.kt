package com.example.mob_comp_hw.geofence

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.mob_comp_hw.data.entity.Notification
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

// Somewhat based on Codemave's tutorial video on the subject as well as Android Developer guide on GeoFencing
// However without the implementation of using keys, or Firebase

// Setting up geofence and its boundaries
class GeofenceAssistant(
    private val context: Context
    ) {
    private val geofencingClient: GeofencingClient = LocationServices.getGeofencingClient(context)

    @RequiresApi(Build.VERSION_CODES.S)
    fun addGeofenceOnMap(notification: Notification) {
        Log.d("Geofence location", "Lat: ${notification.notificationLocation_x}, Long: ${notification.notificationLocation_y}")
        val geofenceAddition = Geofence.Builder() // Private val did not work
            .setCircularRegion(
                notification.notificationLocation_x,
                notification.notificationLocation_y,
                120F)
            .setLoiteringDelay(15000) // 15 seconds
            .setRequestId(notification.notificationTitle)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .build()
        val geofencingRequest = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(geofenceAddition)
            .build()
        val geofenceIntent = Intent(context, GeofenceReceiver::class.java)
            .putExtra("notificationId", notification.notificationId.toString())
            .putExtra("notificationTitle", notification.notificationTitle)
            .putExtra("notificationLocationX", notification.notificationLocation_x)
            .putExtra("notificationLocationY", notification.notificationLocation_y)
        val geofencePendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            geofenceIntent,
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )   // Needs the "or" -condition or will cause an error!

        // Codemave
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    context as Activity,
                    arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                    1507
                )
                // Remove if unnecessary
                Log.d(
                    "Geofence quantity",
                    "Permission phase") //
            } else {
                geofencingClient.addGeofences(geofencingRequest, geofencePendingIntent)
                    .addOnSuccessListener {
                        Log.d(
                            "Geofence quantity",
                            "Geofence successfully added"
                        )
                    }
                    .addOnFailureListener {
                        Log.d(
                            "Geofence quantity",
                            "Failure in adding geofence"
                        )
                    }
            }
        } else {
            geofencingClient.addGeofences(geofencingRequest, geofencePendingIntent)
                .addOnSuccessListener { Log.d("Geofence quantity", "Geofence successfully added") }
                .addOnFailureListener { Log.d("Geofence quantity", "Failure in adding geofence") }

        }
    }

    fun geofenceElimination(id: String) {
        geofencingClient.removeGeofences(listOf(id))
            .addOnSuccessListener {
                Log.d("Geofence quantity", "Geo successfully removed")
            }
            .addOnFailureListener {
                Log.d("Geofence quantity", "Failure in removing geofence")
            }
    }

}