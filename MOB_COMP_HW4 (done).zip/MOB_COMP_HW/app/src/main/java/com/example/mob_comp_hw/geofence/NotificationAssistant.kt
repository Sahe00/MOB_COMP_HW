package com.example.mob_comp_hw.geofence

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.mob_comp_hw.R
import com.example.mob_comp_hw.ui.MainActivity

// Somewhat based on Codemave's tutorial video on the subject as well as Android Developer guide on GeoFencing
// However without the implementation of using keys, or Firebase

class NotificationAssistant(
    private val context: Context
) { val manager: NotificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Definition for the flags below
    companion object {
        const val CHANNEL_ID = "CHANNEL_ID"
        const val CHANNEL_NAME = "CHANNEL_NAME "
    }

    // Note to self, build version code is not a zero "0", it's the letter "O"!
    @SuppressLint("SuspiciousIndentation")
    fun notifChannelCreation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT)
                manager.createNotificationChannel(channel)
        }
    }

    @SuppressLint("SuspiciousIndentation")
    fun notifCreation(
        notifTitle: String, notifMessage: String): Notification {
        val notificationIntent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(notifTitle)
            .setContentText(notifMessage)
            .setContentIntent(pendingIntent)
            .setStyle(NotificationCompat.BigPictureStyle().setBigContentTitle(notifTitle))
            .build()
            return notification
    }



}