package com.example.mob_comp_hw.data.room


import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.mob_comp_hw.data.entity.Category
import kotlinx.coroutines.flow.Flow

/**
Note. using "suspend" with "abstract fun" class resulted in errors while building the file.
Had to remove "suspend" from couple of functions.
 */

@Dao
abstract class CategoryDao {

    @Query("SELECT * FROM categories WHERE name = :name") //Was 'value = .. '
    abstract fun getCategoryWithName(name: String): Category?

    @Query("SELECT * FROM categories WHERE id = :categoryId")
    abstract fun getCategoryWithId(categoryId: Long?): Category?

    @Query("SELECT * FROM categories LIMIT 15")
    abstract fun categories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insert(entity: Category): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insertAll(entities: Collection<Category>)

    @Update(onConflict = OnConflictStrategy.REPLACE)
    abstract fun update(entity: Category)

    @Delete
    abstract fun delete(entity: Category): Int
}

