package com.example.mob_comp_hw.geofence

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import java.text.DecimalFormat

// Somewhat based on Codemave's tutorial video on the subject as well as Android Developer guide on Geofencing
// However without the implementation of using keys, or Firebase

class GeofenceReceiver: BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        // Message to help with debugging, can be removed if unnecessary
        Log.d("GeofenceReceiver:", "GeofenceReceiver in accepting state")
        if (context != null) {
            val geofencingEvent = GeofencingEvent.fromIntent(intent)
            val geofencingTransition = geofencingEvent.geofenceTransition

            // Create variables
            var notifId = "" // Might need to be nullable
            var notifTitle = "" // Might need to be nullable
            var notifLocationX = "" // Might need to be nullable
            var notifLocationY = "" // Might need to be nullable

            // Creation of the actual notification
            if (intent != null) {
                notifId = intent.getStringExtra(
                    "notificationId").toString()
                notifTitle = intent.getStringExtra(
                    "notificationTitle").toString()
                val decimalFormat = DecimalFormat("#.###")
                notifLocationX = decimalFormat.format(intent.getDoubleExtra("notificationLocationX", 0.0))
                notifLocationY = decimalFormat.format(intent.getDoubleExtra("notificationLocationY", 0.0))
            }
            if (geofencingTransition == Geofence.GEOFENCE_TRANSITION_ENTER || geofencingTransition == Geofence.GEOFENCE_TRANSITION_DWELL) {
                val notificationAssistant = NotificationAssistant(context)
                val notification = notificationAssistant.notifCreation(
                    "You are close to '$notifTitle' location!",
                    "At: Lat: $notifLocationX Lng: $notifLocationY"
                ) // More debugging messages, can be removed if unnecessary
                notificationAssistant.manager.notify(1, notification)
                Log.d("GeofenceReceiver:", "Alert")
            } else if (geofencingTransition == Geofence.GEOFENCE_TRANSITION_EXIT) {
                Log.d("GeofenceReceiver:", "Abort")
            }
        }
    }
}