package com.example.mob_comp_hw.ui.map

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.mob_comp_hw.Graph
import com.example.mob_comp_hw.util.rememberMapViewWithLifecycle
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.ktx.awaitMap
import kotlinx.coroutines.launch
import java.util.*
import android.graphics.Color as AndroidColor


@Composable
fun NotificationLocationMap(
    navController: NavController
) {
    lateinit var fusedLocationClient: FusedLocationProviderClient
    val mapView = rememberMapViewWithLifecycle()
    val coroutineScope = rememberCoroutineScope()

    fusedLocationClient = LocationServices.getFusedLocationProviderClient(Graph.appContext)

    Column(modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
        .padding(bottom = 36.dp)
    ) {
        AndroidView({mapView}) { mapView ->
            coroutineScope.launch {
                val map = mapView.awaitMap()
                map.uiSettings.isZoomControlsEnabled = true
                val location = LatLng(65.06, 25.47)
                map.isMyLocationEnabled = true

                fusedLocationClient.lastLocation.addOnSuccessListener {
                    if (it != null) {
                        val latLng = LatLng(it.latitude, it.longitude)
                        map.moveCamera(
                            CameraUpdateFactory.newLatLngZoom(latLng, 10f))
                    } else {
                        map.moveCamera(
                            CameraUpdateFactory.newLatLngZoom(location, 10f)
                        )
                    }
                }

                // This can be removed if unnecessary
                val markerOptions = MarkerOptions()
                    .title("Welcome to Oulu")
                    .position(location)
                map.addMarker(markerOptions)

                setMapLongClick(map = map, navController = navController)
            }
        }
    }
}

private fun setMapLongClick(
    map: GoogleMap,
    navController: NavController
) {
    map.setOnMapLongClickListener { latlng ->
        map.clear() // Only one circle gets drawn (?)
        val snippet = String.format(
            Locale.getDefault(),
            "Lat: %1$.2f, Lng: %2$.2f",
            latlng.latitude,
            latlng.longitude
        )
        map.addCircle(
            CircleOptions()
                .center(latlng)
                .strokeColor(AndroidColor.argb(50, 70, 70, 70))
                .fillColor(AndroidColor.argb(70, 150, 150, 150))
                .radius(120.0)
                .visible(true)

        )
        map.addMarker(
            MarkerOptions().position(latlng).title("Custom notification location").snippet(snippet)
        ).apply {
            navController.previousBackStackEntry
                ?.savedStateHandle
                ?.set("location_data", latlng)
        }
    }
}