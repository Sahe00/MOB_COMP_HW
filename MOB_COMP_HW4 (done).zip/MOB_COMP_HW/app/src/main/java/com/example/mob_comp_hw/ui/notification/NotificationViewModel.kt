package com.example.mob_comp_hw.ui.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.example.mob_comp_hw.Graph
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import com.example.mob_comp_hw.data.room.repository.CategoryRepository
import com.example.mob_comp_hw.data.room.repository.NotificationRepository
import com.example.mob_comp_hw.util.NotificationWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import com.example.mob_comp_hw.R
import androidx.core.app.NotificationManagerCompat.from
import com.example.mob_comp_hw.Graph.notificationRepository
import com.example.mob_comp_hw.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class NotificationViewModel(
    private val notificationRepository: NotificationRepository = Graph.notificationRepository,
    private val categoryRepository: CategoryRepository = Graph.categoryRepository,
): ViewModel() {
    private val _state = MutableStateFlow(NotificationViewState())

    val state: StateFlow<NotificationViewState>
        get() = _state

    suspend fun saveNotification(notification: Notification): Long {
        reminderNotification(notification)
        return notificationRepository.addNotification(notification)
    }

    fun getNotificationWithId(id: Long): Notification {
        return notificationRepository.getNotificationWithId(id)
    }

    init {
        createNotificationChannel(context = Graph.appContext)
        //setOneTimeNotification()
        viewModelScope.launch {
            categoryRepository.categories().collect { categories ->
                _state.value = NotificationViewState(categories)
            }
        }
    }
}

//private fun setOneTimeNotification() {
//    val workManager = WorkManager.getInstance(Graph.appContext)
//    val constraints = Constraints.Builder()
//        .setRequiredNetworkType(NetworkType.CONNECTED)
//        .build()
//
//    val notificationWorker = OneTimeWorkRequestBuilder<NotificationWorker>()
//        .setInitialDelay(10, TimeUnit.SECONDS) // TÄMÄ LASKEMAAN OIKEA AIKA
//        .setConstraints(constraints)
//        .build()
//
//    workManager.enqueue(notificationWorker)
//
//    // Monitoring for state of work
//    workManager.getWorkInfoByIdLiveData(notificationWorker.id)
//        .observeForever { workInfo ->
//            if (workInfo.state == WorkInfo.State.SUCCEEDED) {
//                createSuccessNotification()
//            } else {
//                createErrorNotification()
//            }
//        }
//}

private fun createNotificationChannel(context: Context) {
    // Create the NotificationChannel, but only on API 26+ because
    // the NotificationChannel class is new and not in the support library
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val name = "NotificationChannelName"
        val descriptionText = "NotificationChannelDescriptionText"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel("CHANNEL_ID", name, importance).apply {
            description = descriptionText
        }
        // register the channel with the system
        val notificationManager: NotificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }
}

//private fun createSuccessNotification() {
//    val notificationId = 1
//    val builder = NotificationCompat.Builder(Graph.appContext, "CHANNEL_ID")
//        .setSmallIcon(R.drawable.ic_launcher_background)
//        .setContentTitle("Download completed successfully!")
//        .setContentText("Now fix this shit")
//        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//
//    with(from(Graph.appContext)) {
//        // notificationId is unique for each notification that you define
//        notify(notificationId, builder.build())
//    }
//}

//private fun createErrorNotification() {
//    val notificationId = 1
//    val builder = NotificationCompat.Builder(Graph.appContext, "CHANNEL_ID")
//        .setSmallIcon(R.drawable.ic_launcher_background)
//        .setContentTitle("Error has occurred with your download!")
//        .setContentText("An error was encountered and MAN FIX THIS SHIT")
//        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//
//    with(from(Graph.appContext)) {
//        // notificationId is unique for each notification that you define
//        notify(notificationId, builder.build())
//    }
//}

// Actual notification

private fun reminderNotification(notification: Notification) {
    val workManager = WorkManager.getInstance(Graph.appContext)
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    if(notification.notificationTime.toInt() != 0){ //If something other than 0

    val notificationWorker = OneTimeWorkRequestBuilder<NotificationWorker>()
        .setInitialDelay(notification.notificationTime.toLong(), TimeUnit.SECONDS)
        .setConstraints(constraints)
        .build()

    workManager.enqueue(notificationWorker)

    // Monitoring for state of work
    workManager.getWorkInfoByIdLiveData(notificationWorker.id)
        .observeForever { workInfo ->
            if (workInfo.state == WorkInfo.State.SUCCEEDED) {
                createSuccessNotificationReminder(notification)
                val scope = CoroutineScope(Dispatchers.Default)
                scope.launch {
                    notificationRepository.updateSeen(notification.notificationId)
                    Log.d("notification", "id: "+notification.notificationId)
                }
            }
        }
    }
}

private fun createSuccessNotificationReminder(notification: Notification) {
    val notificationId = notification.notificationId.toInt()
    val resultIntent = Intent(Graph.appContext, MainActivity::class.java)
    val resultPendingIntent: PendingIntent? = TaskStackBuilder.create(Graph.appContext).run {
        addNextIntentWithParentStack(resultIntent)
        getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    var vibrationPattern = longArrayOf(0)
    if(notification.notificationVibration) {
        vibrationPattern = longArrayOf(500)
    }

    val builder = NotificationCompat.Builder(Graph.appContext, "CHANNEL_ID")
        .setSmallIcon(R.drawable.ic_launcher_background)
        .setContentTitle("You have a new notification!")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setContentText("Reminder set for: '${notification.notificationTitle}' after ${notification.notificationTime} seconds")
        .addAction(R.drawable.ic_launcher_background, "Check it out",
            resultPendingIntent)
        .setVibrate(vibrationPattern)
        .setDefaults(android.app.Notification.DEFAULT_VIBRATE)

    with(NotificationManagerCompat.from(Graph.appContext)) {
        // notificationId is unique for each notification that you define
        notify(notificationId, builder.build())
    }
}

//private fun createNotificationMade(notification: Notification) {
//    val notificationId = 2
//    val builder = NotificationCompat.Builder(Graph.appContext, "CHANNEL_ID")
//        .setSmallIcon(R.drawable.ic_launcher_background)
//        .setContentTitle("You have a notification!")
//        .setContentText("Remember ${notification.notificationTitle} on ${notification.notificationTime}")
//        .setPriority(NotificationCompat.PRIORITY_HIGH)
//    with(from(Graph.appContext)) {
//        notify(notificationId, builder.build())
//    }
//}

data class NotificationViewState(
    val categories: List<Category> = emptyList()
)