package com.example.mob_comp_hw.ui.notification

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.unit.dp
import com.example.mob_comp_hw.data.entity.Category
import com.example.mob_comp_hw.data.entity.Notification
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun Notification(
    onBackPress: () -> Unit,
    viewModel: NotificationViewModel = viewModel()
) {
    val focusManager = LocalFocusManager.current
    val viewState by viewModel.state.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val title = rememberSaveable { mutableStateOf("") }
    val category = rememberSaveable { mutableStateOf("") }
    val seconds = rememberSaveable{ mutableStateOf("") }
    val minutes = rememberSaveable{ mutableStateOf("") }
    val hours = rememberSaveable{ mutableStateOf("") }
    val days = rememberSaveable { mutableStateOf("") }
    val months = rememberSaveable { mutableStateOf("") }
    val years = rememberSaveable { mutableStateOf("") }
    val withNotif = remember { mutableStateOf(true)}
    val withLocation = remember { mutableStateOf(true)}
    val withVibration = remember { mutableStateOf(true)}
    // MIGHT NEED DATE HANDLED HERE


    Surface {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopAppBar {
                IconButton(
                    onClick = onBackPress
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null
                    )
                }
                Text(text = "Notification")
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.padding(28.dp)
            ) {
                OutlinedTextField(
                    value = title.value,
                    onValueChange ={ title.value = it },
                    label = { Text(text = "What do you need to remember?") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                )
                Spacer(modifier = Modifier.height(10.dp))

                CategoryListDropdown(
                    viewState = viewState,
                    category = category
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row {
//                    OutlinedTextField(
//                        value = years.value,
//                        onValueChange = { years.value = it },
//                        label = { Text("yyyy") },
//                        shape = RoundedCornerShape(20),
//                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number,
//                            imeAction = ImeAction.Next
//                        ),
//                        keyboardActions = KeyboardActions(
//                            onNext = { focusManager.moveFocus(FocusDirection.Right) }
//                        )
//                    )
//                    Spacer(modifier = Modifier.width(1.dp))
//                    OutlinedTextField(
//                        value = months.value,
//                        onValueChange = { months.value = it },
//                        label = { Text("mm") },
//                        shape = RoundedCornerShape(20),
//                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number,
//                            imeAction = ImeAction.Next
//                        ),
//                        keyboardActions = KeyboardActions(
//                            onNext = { focusManager.moveFocus(FocusDirection.Right) }
//                        )
//                    )
//                    Spacer(modifier = Modifier.width(1.dp))
//                    OutlinedTextField(
//                        value = days.value,
//                        onValueChange = { days.value = it },
//                        label = { Text("dd") },
//                        shape = RoundedCornerShape(20),
//                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
//                        keyboardOptions = KeyboardOptions(
//                            keyboardType = KeyboardType.Number,
//                            imeAction = ImeAction.Next
//                        ),
//                        keyboardActions = KeyboardActions(
//                            onNext = { focusManager.moveFocus(FocusDirection.Right) }
//                        )
//                    )
                    Spacer(modifier = Modifier.width(1.dp))
                    OutlinedTextField(
                        value = hours.value,
                        onValueChange = { hours.value = it },
                        label = { Text("Hr") },
                        shape = RoundedCornerShape(20),
                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Right) }
                        )
                    )
                    Spacer(modifier = Modifier.width(1.dp))
                    OutlinedTextField(
                        value = minutes.value,
                        onValueChange = { minutes.value = it },
                        label = { Text("Min") },
                        shape = RoundedCornerShape(20),
                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.clearFocus() }
                        )
                    )
                    Spacer(modifier = Modifier.width(1.dp))
                    OutlinedTextField(
                        value = seconds.value,
                        onValueChange = { seconds.value = it },
                        label = { Text("S") },
                        shape = RoundedCornerShape(20),
                        modifier = Modifier.requiredWidthIn(min = 50.dp, max = 60.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.clearFocus() }
                        )
                    )
                }

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    enabled = true,
                    onClick = {
                        coroutineScope.launch {
//                            if(years.value == "" || !withNotif.value){years.value="0"}
//                            if(months.value == "" || !withNotif.value){months.value="0"}
//                            if(days.value == "" || !withNotif.value){days.value="0"}
                            if(hours.value == "" || !withNotif.value){hours.value="0"}
                            if(minutes.value == "" || !withNotif.value){minutes.value="0"}
                            if(seconds.value == "" || !withNotif.value){seconds.value="0"} // If left empty -> App Crash
//                            var locx = (latlng?.latitude ?: 0.0)
//                            var locy = (latlng?.longitude ?: 0.0)
//                            if(!withLocation.value) {
//                                locx = 0.0
//                                locy = 0.0
//                            }
                            viewModel.saveNotification(
                                Notification(
                                    notificationTitle = title.value,
                                    notificationLocation_x = null,
                                    notificationLocation_y = null,
                                    notificationTime = (((hours.value.toLong()*60*60)+minutes.value.toLong())*60+seconds.value.toLong()).toString(),
                                    notificationCreationTime = Date().time,
                                    notificationCategoryId = getCategoryId(viewState.categories, category.value),
                                    notificationCreatorId = 0,
                                    notificationReminderSeen = if((((hours.value.toLong()*60*60)+minutes.value.toLong())*60+seconds.value.toLong()).toInt() == 0 || !withLocation.value ){
                                        1
                                    }else{
                                        0
                                    },
                                    notificationHour = hours.value + "h" + minutes.value + "m" + seconds.value + "s",
                                    notificationLocation = withLocation.value,
                                    notificationVibration = withVibration.value
                                )
                            )
                        }
                        onBackPress()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .size(60.dp),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Save reminder")
                }
            }
        }
    }
}


private fun getCategoryId(categories: List<Category>, categoryName: String): Long {
    return categories.first { category -> category.name == categoryName }.id
}

@Composable
private fun CategoryListDropdown(
    viewState: NotificationViewState,
    category: MutableState<String>
) {
    var expanded by remember { mutableStateOf(false) }
    val icon = if (expanded) {
        Icons.Filled.ArrowDropUp
    } else {
        Icons.Filled.ArrowDropDown
    }


    Column() {
        OutlinedTextField(
            value = category.value,
            onValueChange = { category.value = it},
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Category") },
            shape = RoundedCornerShape(50),
            readOnly = true,
            trailingIcon = {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.clickable { expanded = !expanded }
                )
            }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            viewState.categories.forEach { dropDownOption ->
                DropdownMenuItem(
                    onClick = {
                        category.value = dropDownOption.name
                        expanded = false
                    }
                ) {
                    Text(dropDownOption.name)
                }

            }
        }
    }
}



//54:16