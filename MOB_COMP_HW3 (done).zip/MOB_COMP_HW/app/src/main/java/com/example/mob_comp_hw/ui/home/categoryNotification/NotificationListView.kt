package com.example.mob_comp_hw.ui.home.categoryNotification

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

@Composable
fun NotificationListView(
    modifier: Modifier = Modifier,
    navController: NavController
) {

}