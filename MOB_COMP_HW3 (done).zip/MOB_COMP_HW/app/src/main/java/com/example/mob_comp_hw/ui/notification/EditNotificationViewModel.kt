package com.example.mob_comp_hw.ui.notification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mob_comp_hw.Graph
import com.example.mob_comp_hw.data.entity.Notification
import com.example.mob_comp_hw.data.room.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class EditNotificationViewModel(
    private val notificationId: Long,
    private val notificationRepository: NotificationRepository = Graph.notificationRepository,
): ViewModel() {
    private val _state = MutableStateFlow(EditNotificationViewState(null))

    val state: StateFlow<EditNotificationViewState>
        get() = _state

    suspend fun saveNotification(notification: Notification) {
        return notificationRepository.updateNotification(notification)
    }

    fun getNotificationWithId(id: Long): Notification {
        return notificationRepository.getNotificationWithId(id)
    }
    init {
        viewModelScope.launch {
            notificationRepository.getNotification(notificationId).apply {
                _state.value = EditNotificationViewState(this)
            }
        }
    }
}


data class EditNotificationViewState(
    val notification: Notification?
)