package com.example.mob_comp_hw.data.room

import androidx.room.*
import com.example.mob_comp_hw.data.entity.Notification
import kotlinx.coroutines.flow.Flow

@Dao
abstract class NotificationDao {
    @Query("""
        SELECT notifications.* FROM notifications
        INNER JOIN categories ON notifications.category_id = categories.id
        WHERE category_id = :categoryId
    """)
    abstract fun notificationsFromCategory(categoryId: Long): Flow<List<NotificationToCategory>>

    @Query("""SELECT * FROM notifications WHERE id = :notificationId""")
    abstract fun notification(notificationId: Long): Notification

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insert(entity: Notification): Long

    @Update(onConflict = OnConflictStrategy.REPLACE)
    abstract fun update(entity: Notification)

    @Delete
    abstract fun delete(entity: Notification): Int

    // TÄYTYY MAHDOLLISESTI LISÄTÄ NOTIFI-LIMIT TÄHÄN

    @Query("DELETE FROM notifications WHERE id = :notificationId")
    abstract fun deleteById(notificationId: Long)

    @Query("UPDATE notifications SET notification_seen=1 WHERE id = :notificationId")
    abstract fun updateSeen(notificationId: Long)

    @Query("UPDATE notifications SET notification_seen=0 WHERE id = :notificationId")
    abstract fun updateSeenBack(notificationId: Long)
}